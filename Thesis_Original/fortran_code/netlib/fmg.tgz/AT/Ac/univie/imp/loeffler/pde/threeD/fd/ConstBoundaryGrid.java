package AT.Ac.univie.imp.loeffler.pde.threeD.fd;

/**
 * An interface to the constant methods of class BoundaryGrid.
 *
 * @author Gerald Loeffler (Gerald.Loeffler@univie.ac.at)
 */
public interface ConstBoundaryGrid extends ConstGrid {}
