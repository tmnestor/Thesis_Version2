package AT.Ac.univie.imp.loeffler.pde.threeD.fd;

/**
 * An interface to the constant methods of class NoBoundaryGrid.
 *
 * @author Gerald Loeffler (Gerald.Loeffler@univie.ac.at)
 */
public interface ConstNoBoundaryGrid extends ConstGrid {}
