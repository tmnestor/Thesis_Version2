package AT.Ac.univie.imp.loeffler.pde.threeD.fd;

/**
 * Exception class that is thrown if FMG.waitForResult() is called although the FMG algorithm is currently not executing 
 * in a thread.
 *
 * @author Gerald Loeffler (Gerald.Loeffler@univie.ac.at)
 */
public class FMGNotExecutingException extends Exception {
     /**
      * construct with no particular message
      */
     public FMGNotExecutingException() {};
     
     /**
      * construct with the given message
      *
      * @param msg the message
      */
     public FMGNotExecutingException(String msg) {super(msg);};
}
