package AT.Ac.univie.imp.loeffler.pde.threeD.fd;

/**
 * Exception class that is thrown if FMG.fmg() is called while another instance of the method is already executing in
 * its thread.
 *
 * @author Gerald Loeffler (Gerald.Loeffler@univie.ac.at)
 */
public class FMGAlreadyExecutingException extends Exception {
     /**
      * construct with no particular message
      */
     public FMGAlreadyExecutingException() {};
     
     /**
      * construct with the given message
      *
      * @param msg the message
      */
     public FMGAlreadyExecutingException(String msg) {super(msg);};
}
