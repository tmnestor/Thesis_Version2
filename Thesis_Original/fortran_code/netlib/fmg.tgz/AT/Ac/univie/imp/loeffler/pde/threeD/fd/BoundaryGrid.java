package AT.Ac.univie.imp.loeffler.pde.threeD.fd;
import  AT.Ac.univie.imp.loeffler.util.*;

/**
 * An implementation of Grid where a boundary of some kind is supported.
 *
 * @author Gerald Loeffler (Gerald.Loeffler@univie.ac.at)
 */
public abstract class BoundaryGrid extends Grid implements ConstBoundaryGrid {
     /**
      * construct from size and initial value for all elements in the interior.
      *
      * @param size          the size of the grid ( > 0)
      * @param interiorValue the initial value to which all grid elements will be set
      */
     protected BoundaryGrid(int size, double interiorValue) {
          super(size,interiorValue);
     }
}
